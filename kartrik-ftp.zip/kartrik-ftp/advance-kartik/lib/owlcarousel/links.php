<?php
  $links = array(
    'css' => 'lib/owlcarousel/assets/owl.carousel.min.css',
    'js' => 'lib/owlcarousel/owl.carousel.min.js'
  );
?>
